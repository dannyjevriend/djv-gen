#!/bin/sh
# Run gen.py in a cached Python environment. The first call installs it.
#
# This wrapper never imports the SDK: a normal call pays only the interpreter
# start, not a second copy of drawthings-py.
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
VENV=${DRAWTHINGS_VENV_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/djv-tools-gen/venv}

fail() {
    printf '{"ok": false, "error": "%s"}\n' "$1"
    exit 1
}

if [ ! -x "$VENV/bin/python" ]; then
    if ! "$DIR/install.sh" >&2; then
        fail "Could not install the Python environment for this skill."
    fi
fi

exec "$VENV/bin/python" "$DIR/gen.py" "$@"
