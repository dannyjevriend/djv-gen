# Gen (lean)

Images, edits, and short videos with local Draw Things models. One command,
one JSON object back.

## Install

Copy this folder into your skills folder. The first run creates a cached Python
environment at `~/.local/share/djv-tools-gen/venv` with
`drawthings-py[ffmpeg]==0.4.0`. It needs `uv` or Python 3.11+.

## Configure

In Draw Things: **Settings → API Server**, with gRPC, TLS, and port `7859`.

Copy `config.env.example` to `config.env` and edit it, or export
`DRAWTHINGS_HOST` / `DRAWTHINGS_PORT`.

## Use

```bash
./run.sh --prompt-stdin <<'PROMPT'
a lighthouse at sunset, 35mm, soft haze
PROMPT

./run.sh "a paper boat" --size 16:9 --quality hero
./run.sh "same room at night" --init room.png --strength 0.9
./run.sh "a slow dolly in" --init room.png --video --seconds 5
./run.sh --from gen/lighthouse_0001.png --quality hero
```

Video is a ProRes 4444 `.mov` master by default; add `--h264` for a small MP4.

Successful results include `display`, the files to attach in chat: the rendered
images, or the poster and contact sheet for a video.

`--dry-run` resolves a job without rendering. `--models`, `--sizes`, and
`--version` are offline.

## What is in the folder

- `gen.py` — the whole CLI, renderer, saver, and replay logic
- `presets/` — Draw Things configurations
- `run.sh`, `install.sh` — launcher and one-time environment build
- `SKILL.md` — the agent-facing instructions
- `tests/` — offline unit tests, development only (not in the package)

Outputs default to `./gen/`. Every PNG carries the Draw Things settings in its
XMP, which is what `--from` replays.
